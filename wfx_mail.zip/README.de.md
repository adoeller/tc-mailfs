# MailFS – Total Commander WFX Plugin

E-Mail-Zugriff per IMAP/POP3 als virtuelles Dateisystem in Total Commander.

---

## Überblick

MailFS ist ein WFX-Plugin (Filesystem-Plugin) für Total Commander 64-Bit, das konfigurierte
E-Mail-Konten als Ordner in der Netzwerkumgebung von TC darstellt.

- **Root-Ebene:** Ein Ordner pro konfiguriertem Konto
- **Kontoebene:** Echte IMAP-Mailbox-Hierarchie des Servers
- **Ordnerebene:** Nachrichten als virtuelle `.eml`-Dateien
- **Herunterladen:** Nachrichten durch Kopieren aus TC als vollständige EML-Dateien exportieren
- **Versenden:** Voller SMTP-Versand (siehe „Nachricht senden" unten)

---

## Voraussetzungen

MailFS gibt es als 32-Bit-Build (`mailfs.wfx`) und als 64-Bit-Build
(`mailfs.wfx64`) — verwende die zu deinem Total Commander passende Variante
(32-Bit- und 64-Bit-TC können die jeweils andere Plugin-DLL nicht laden).

| Komponente | Version |
|---|---|
| Total Commander | 10.0+ (32-Bit oder 64-Bit) |
| Windows | 10 / 11 |
| OpenSSL (64-Bit-TC) | 3.x — `libssl-3-x64.dll`, `libcrypto-3-x64.dll` |
| OpenSSL (32-Bit-TC) | 3.x — `libssl-3.dll`, `libcrypto-3.dll` |

OpenSSL 3.x für Windows hier herunterladen: https://slproweb.com/products/Win32OpenSSL.html

Auf dieser Seite gibt es mehrere Installer – zwei Dinge sind wichtig und
werden leicht verwechselt:
- **Version 3.x, nicht 1.1.x.** Die Seite bietet beides an; nur 3.x liefert
  die DLL-Namen `libssl-3*`/`libcrypto-3*`, die MailFS lädt. Eine
  1.1.x-Installation liefert stattdessen `libssl-1_1*`/`libcrypto-1_1*`,
  die MailFS nicht findet.
- **Die Bitness muss zum Total Commander passen, nicht zu Windows.** Trotz
  des Seitennamens („Win32OpenSSL") gibt es dort beide Installer:
  **„Win64 OpenSSL v3.x"** (→ `libssl-3-x64.dll`/`libcrypto-3-x64.dll`, für
  64-Bit-TC/`mailfs.wfx64`) und **„Win32 OpenSSL v3.x"** (→
  `libssl-3.dll`/`libcrypto-3.dll`, für 32-Bit-TC/`mailfs.wfx`). Bei
  64-Bit-Windows mit 64-Bit-TC den Win64-Installer wählen. Die
  „Light"-Variante reicht in beiden Fällen aus – nur die beiden DLLs werden
  benötigt.

---

## Installation

1. Folgende Dateien in einen Ordner deiner Wahl kopieren (z. B. `C:\TC\Plugins\mailfs\`):
   - `mailfs.wfx` (32-Bit-TC) bzw. `mailfs.wfx64` (64-Bit-TC) — siehe Voraussetzungen oben
   - das passende Paar OpenSSL-DLLs (`libssl-3-x64.dll` + `libcrypto-3-x64.dll` für 64-Bit,
     bzw. `libssl-3.dll` + `libcrypto-3.dll` für 32-Bit)
   - Ordner `locale\` (Sprachdateien; ohne diesen Ordner läuft das Plugin auf Englisch)

2. In Total Commander: **Konfiguration → Optionen → Plugins → Dateisystem-Plugins → Hinzufügen**

3. `mailfs.wfx` (bzw. `mailfs.wfx64` bei 64-Bit-TC) auswählen und bestätigen.

4. Das Plugin erscheint jetzt in der TC-Netzwerkumgebung (linkes Panel: `\` → Netzwerk → MailFS).

---

## Konto konfigurieren

**Methode 1 – über TC-Menü:**
Im linken Panel zum MailFS-Plugin navigieren → **Alt+Enter** oder **Datei → Eigenschaften**.

**Methode 2 – direkt:**
Im TC-Netzwerkbereich mit der rechten Maustaste auf das MailFS-Icon → **Eigenschaften**.

Im Dialog **MailFS-Konten**:
1. **Neu...** klicken
2. E-Mail-Adresse eingeben → Anbieter wird automatisch erkannt
3. **Automatisch konfigurieren** klicken → Server/Port wird vorausgefüllt
4. Authentifizierung wählen:
   - **OAuth2:** „Im Browser anmelden..." → Browser öffnet sich → nach Anmeldung Token gespeichert
   - **Passwort:** „Passwort eingeben..." → sicher im Windows Credential Manager gespeichert
5. **Verbindung testen** → Verbindung zum IMAP-Server prüfen
6. Optional (nur IMAP): **Edit folders...** → ruft die Ordnerliste vom Server
   ab und lässt auswählen, welche Ordner im TC-Panel angezeigt werden sollen
   (anklicken schaltet einen Ordner um, kein Ctrl/Shift nötig). Sind alle
   Ordner ausgewählt, werden künftig auch neu angelegte Server-Ordner
   automatisch mit angezeigt; ist nur eine Teilmenge gewählt, bleibt es bei
   genau dieser Auswahl.
7. Optional (zum Mailversand): **SMTP...** → SMTP-Server/Port/Verschlüsselung
   einstellen (per **Automatisch konfigurieren** wie beim Empfang), sowie
   Absenderadresse und **Kopie in „Gesendet" speichern** (Standard: aus,
   nur bei IMAP wirksam). Benutzername/Passwort/OAuth2 werden vom
   eingestellten Empfangskonto übernommen, nicht separat abgefragt.
8. **OK**

---

## Unterstützte Anbieter

| Anbieter | Automatisch erkannt | OAuth2 | Passwort |
|---|---|---|---|
| Gmail | ✓ | ✓ (empfohlen) | ✓ (App-Passwort nötig) |
| Outlook / Microsoft 365 | ✓ | ✓ (empfohlen) | ✓ |
| Yahoo | ✓ | ✓ | ✓ (App-Passwort) |
| GMX | ✓ | – | ✓ |
| WEB.DE | ✓ | – | ✓ |
| iCloud | ✓ | – | ✓ (App-Passwort) |
| Benutzerdefiniert | – | Optional | ✓ |

---

## Nutzung

### Nachrichten anzeigen
Im TC-Panel zum Konto navigieren → IMAP-Ordner öffnen → Nachrichten erscheinen als `.eml`-Dateien.
Verschachtelte/spezielle Ordner, die der Server meldet (z. B. Gmails
`[Google Mail]/Gesendet`, `[Google Mail]/Alle Nachrichten` usw.), werden
angezeigt und lassen sich wie jeder andere Ordner betreten – unter ihrem
vollständigen serverseitigen Pfad als Ordnername.

### Nachricht herunterladen / öffnen
- **F5 (Kopieren):** Nachricht als `.eml`-Datei auf lokales Laufwerk kopieren
- Danach mit installiertem EML-Viewer öffnen (z. B. Outlook, Thunderbird, oder ein TC-Viewer-Plugin)

### Custom Columns einrichten
1. In einem Mailordner: **Ansicht → Benutzerdefinierte Spalten konfigurieren**
2. Neues Profil → **Plugin-Spalten hinzufügen** → **mailfs** auswählen
3. Verfügbare Felder: **Von, An, Betreff, Empfangsdatum, Größe, Anhang, Flags,
   Status, TotalMails, NewMails**
4. Alternativ: Das Plugin schlägt ein Standard-Layout über `FsContentGetDefaultView` vor.

**Status** (`<fs>.Status`) — pro Nachricht: `new` wenn auf dem Server als
ungelesen markiert, `old` wenn gelesen, `---` wenn unbekannt (z. B. POP3,
das keinen Lese-Status kennt). Wert folgt der UI-Sprache.

**TotalMails** / **NewMails** (`<fs>.TotalMails`, `<fs>.NewMails`) — pro
**Ordner**-Zeile (z. B. beim Anzeigen der Ordnerliste eines Kontos):
Gesamtzahl bzw. Anzahl ungelesener Nachrichten in diesem Ordner (per IMAP
STATUS ermittelt). Bei Nachrichten-Zeilen, dem Konto selbst und bei POP3
immer `---`.

### Konto testen
Im Dialog **MailFS-Konten** → Konto auswählen → **Testen**

### Nachricht senden
Im Konto-Ordner erscheint unten der Eintrag **„*** New mail ***"**
(lokalisiert). Öffnen (Enter/Doppelklick) startet das Verfassen-Fenster:
An/Cc/Bcc (Komma- oder Semikolon-getrennt), Betreff, Text sowie
**Anhängen...** (Mehrfachauswahl durch wiederholtes Klicken). **Senden**
verbindet zum konfigurierten SMTP-Server, authentifiziert mit den
Empfangskonto-Zugangsdaten und verschickt die Nachricht; ist
**„Kopie in Gesendet speichern"** aktiviert (nur IMAP), wird zusätzlich eine
Kopie in den erkannten „Gesendet"-Ordner geschrieben (Fehlschlag dabei wird
nur protokolliert, der Versand selbst gilt als erfolgreich). SMTP muss zuvor
im Konto-Dialog über **SMTP...** eingerichtet sein.

**Datei(en) per Kopieren/Ziehen anhängen:** Wird eine oder mehrere Dateien
per F5 oder Drag & Drop in ein Konto kopiert – egal in welchen Ordner –
öffnet sich automatisch das Verfassen-Fenster mit der/den Datei(en) bereits
als Anhang. Die Originaldatei wird dabei nicht verändert oder gelöscht
(auch nicht bei „Verschieben"); MailFS legt sich intern eine eigene Kopie an.

### Adressbuch
Neben An/Cc/Bcc im Verfassen-Fenster öffnet der Knopf **„AB"** das
Adressbuch (kontospezifisch nicht getrennt – ein gemeinsames Adressbuch für
alle Konten). Die Liste zeigt jede gespeicherte Adresse mit zwei
Kontrollkästchen: **Favorit** (wird nie automatisch entfernt) und
**Standard für An/Cc/Bcc** (wird beim Öffnen eines neuen Verfassen-Fensters
automatisch in das jeweilige Feld eingetragen – je Feld separat
gespeichert). Auswahl mehrerer Adressen per Klick, Umschalten der beiden
Kontrollkästchen wirkt auf alle markierten Zeilen. Doppelklick auf eine
Adresse übernimmt genau diese in das Feld, dessen „AB"-Knopf das Adressbuch
geöffnet hat; **Übernehmen** übernimmt alle markierten Adressen
kommagetrennt. **Entfernen** löscht eine Adresse endgültig (auch Favoriten).

Nach jedem erfolgreichen Versand werden alle Empfänger (An/Cc/Bcc)
automatisch im Adressbuch vermerkt. Beim Speichern werden alle Favoriten
sowie die zuletzt verwendeten `MaxAddresses` Nicht-Favoriten behalten,
ältere Nicht-Favoriten fallen automatisch heraus.

### Antworten per F7 ("neuer Ordner")
In einer Nachrichtenliste **F7** drücken und als Namen für den neuen Ordner
exakt den Dateinamen einer vorhandenen Nachricht **ohne** `.eml`-Endung
eingeben (z. B. `20260611_0638_Badminton News 6_26_UID102017638` für die
Datei `...UID102017638.eml`). Es wird **kein** Ordner angelegt – stattdessen
öffnet sich das Verfassen-Fenster als Antwort auf genau diese Nachricht:
Betreff mit `RE: `-Präfix, An/Cc aus der Originalmail übernommen, im Text
zwei Leerzeilen, eine Zeile `---`, darunter der zitierte Originaltext, sowie
passend gesetzte `In-Reply-To`/`References`-Header für die Thread-Zuordnung
beim Empfänger. Funktioniert für IMAP- und POP3-Konten. Jeder andere
Ordnername (der nicht auf eine vorhandene Nachricht passt) scheitert wie
gewohnt, da echtes Anlegen von Ordnern nicht unterstützt wird.

---

## Sprache

MailFS ist lokalisiert (Deutsch, Englisch, Russisch, Ukrainisch). Im Dialog
**MailFS-Konten** kann über das Kombinationsfeld **Sprache** eine feste
Sprache gewählt werden; **Automatisch (Systemsprache)** übernimmt die
UI-Sprache von Windows. Ist die erkannte Sprache nicht verfügbar, wird
automatisch Englisch verwendet.

Die Sprachdateien liegen im Ordner `locale\` neben `mailfs.wfx`
(`mailfs.de.po`, `mailfs.en.po`, `mailfs.ru.po`, `mailfs.uk.po`) und können
mit einem gettext/PO-Editor (z. B. Poedit) angepasst oder erweitert werden.
Englisch ist die im Plugin einkompilierte Standardsprache und benötigt keine
`.po`-Datei.

Die Auswahl wird in `mailfs.ini` gespeichert (siehe unten) und wirkt sofort
– der Dialog wird beim Sprachwechsel automatisch neu geöffnet.

---

## Logging

Im Dialog **MailFS-Konten** gibt es neben der Sprachauswahl ein
Kontrollkästchen **Logging aktivieren**. Es ist **standardmäßig aus**. Bei
Aktivierung schreibt MailFS ein ausführliches Diagnose-Log (IMAP/POP3/SMTP-
Protokollverkehr, Dialog-Ereignisse, OAuth2-Ablauf usw.) nach
`%TEMP%\mailfs_debug.log`. Das Umschalten wirkt sofort (kein Neustart
nötig) und wird als `Logging=0`/`1` in `mailfs.ini` gespeichert. Im
Normalbetrieb ausgeschaltet lassen; nur bei der Fehlersuche aktivieren, da
das Log schnell wachsen kann und E-Mail-Metadaten (Betreffs, Adressen,
Ordnernamen) enthalten kann.

---

## Konfigurationsdateien

### mailfs.ini
Liegt im gleichen Ordner wie `mailfs.wfx`.
Enthält **ausschließlich nicht-sensible** Konfiguration (Server, Port, Verschlüsselung etc.).
**Keine Passwörter oder Tokens** werden hier gespeichert.

Beispiel:
```ini
[Global]
Version=1
AccountCount=1
Language=auto
Logging=0

[Account0]
ID=a1b2c3d4-e5f6-7890-abcd-ef1234567890
DisplayName=Mein Gmail
Email=user@gmail.com
Provider=1
Active=True
Protocol=0
ImapServer=imap.gmail.com
ImapPort=993
ImapEncryption=1
ImapUsername=user@gmail.com
ImapAuth=1
Pop3Server=pop.gmail.com
Pop3Port=995
Pop3Encryption=1
Pop3Username=user@gmail.com
Pop3Auth=1
VisibleFolders=INBOX|INBOX.Sent
SmtpServer=smtp.gmail.com
SmtpPort=587
SmtpEnc=2
SmtpFrom=user@gmail.com
SmtpSaveToSent=False
```

`VisibleFolders` wird über **Edit folders...** im Konto-Dialog gesetzt
(`|`-getrennte Liste von Ordnerpfaden). Fehlt der Schlüssel oder ist er leer,
werden alle Ordner des Kontos angezeigt.

`StartFolder` wird über das Feld **Start folder** im Konto-Dialog gesetzt.
Standard ist `INBOX` bei POP3-Konten und leer bei IMAP-Konten (kein
automatischer Sprung). Ist ein Wert gesetzt, springt das Betreten des
Kontos im TC-Panel automatisch direkt in diesen Ordner. Bei POP3 ist nur
`INBOX` ein gültiger Wert – jeder andere konfigurierte Wert wird
zurückgewiesen (das Konto lässt sich dann schlicht nicht betreten), statt
stillschweigend auf INBOX auszuweichen.

`SmtpServer`/`SmtpPort`/`SmtpEnc` (0=Auto, 1=TLS, 2=STARTTLS, 3=keine) und
`SmtpFrom` werden über **SMTP...** im Konto-Dialog gesetzt; `SmtpFrom` leer
bedeutet „benutze Email". `SmtpSaveToSent` (Standard `False`) steuert, ob
beim Senden zusätzlich eine Kopie per IMAP APPEND in den „Gesendet"-Ordner
geschrieben wird. Benutzername/Passwort/OAuth2-Tokens für den Versand werden
**nicht** separat gespeichert, sondern vom aktiven Empfangsprotokoll
(IMAP/POP3) übernommen.

Das Adressbuch (siehe „Adressbuch" oben) liegt im eigenen Abschnitt
`[Addresses]`, kontounabhängig:
```ini
[Addresses]
MaxAddresses=10
Count=2
Address0=chef@firma.de
Address0.Fav=1
Address0.DefTo=0
Address0.DefCc=1
Address0.DefBcc=0
Address0.Tick=5
Address1=kollege@firma.de
Address1.Fav=0
Address1.DefTo=0
Address1.DefCc=0
Address1.DefBcc=0
Address1.Tick=7
```
`MaxAddresses` begrenzt nur die **Nicht**-Favoriten (älteste zuerst
entfernt); Favoriten (`.Fav=1`) bleiben unbegrenzt erhalten. `.DefTo`/
`.DefCc`/`.DefBcc` steuern die automatische Vorbelegung beim Öffnen eines
neuen Verfassen-Fensters, `.Tick` ist ein interner Zähler für „zuletzt
verwendet" (höher = neuer).

### Windows Credential Manager
Passwörter, OAuth2-Tokens und OAuth2-Client-Secrets werden im Windows
Credential Manager gespeichert – nie in `mailfs.ini`.
Eintragsformat: `MailFS/{Konto-ID}/{password|oauth2_access|oauth2_refresh|client_secret}`
(die OAuth2-**Client-ID** selbst ist nicht sensibel und bleibt in `mailfs.ini`.)

Zu finden unter: **Systemsteuerung → Benutzerkonten → Credential Manager → Windows-Anmeldeinformationen**

---

## Sicherheit

- Passwortauthentifizierung **nur** über verschlüsselte Verbindungen (TLS/STARTTLS)
- Zertifikatsprüfung standardmäßig **strikt aktiviert**
- Keine Klartextspeicherung von Passwörtern oder Tokens
- Unsichere Verbindungen (Port 143/110 ohne Verschlüsselung) müssen explizit aktiviert werden

---

## Kompilieren (Entwickler)

Voraussetzungen:
- Lazarus 2.2+ / Free Pascal Compiler 3.2+ (https://www.lazarus-ide.org/)
  (wird über `lazbuild` gebaut, nicht direkt über `fpc` - MailFS hängt vom
  LazUtils-Package ab (`Translations`-Unit für die `.po`-Sprachdateien),
  dessen Unit-Suchpfade nur `lazbuild`/die IDE automatisch auflösen)
- OpenSSL 3.x Header / DLLs im Projektverzeichnis

```bat
build.bat
```

Ausgabe: `build\mailfs.wfx`

Projektstruktur:
```
mailfs/
├── mailfs.dpr              Haupt-DLL-Projektdatei
├── build.bat               Build-Script
├── src/
│   ├── wfx_api.pas         WFX SDK Typdefinitionen
│   ├── imap_types.pas      Datenmodell (Konten, Ordner, Nachrichten)
│   ├── ssl_layer.pas       TCP+TLS Socket-Schicht (OpenSSL dynamisch)
│   ├── imap_client.pas     IMAP4rev1 Client
│   ├── pop3_client.pas     POP3 Client
│   ├── smtp_client.pas     SMTP Client (Versand)
│   ├── credential_mgr.pas  Windows Credential Manager Wrapper
│   ├── account_manager.pas Kontoverwaltung + INI-Persistenz
│   ├── msg_cache.pas       Thread-sicherer Metadaten-Cache
│   ├── vfs_core.pas        Virtuelles Dateisystem + Verbindungspool
│   ├── custom_columns.pas  TC Custom Columns (Content Plugin)
│   ├── dlg_accounts.pas    Dialog 1: Kontenverwaltung
│   ├── dlg_edit_account.pas Dialog 2: Konto bearbeiten/anlegen (inkl. SMTP-Settings)
│   ├── dlg_compose.pas     Dialog 3: Nachricht verfassen/senden
│   └── mailfs_main.pas     WFX-Einstiegspunkte (Exports)
└── docs/
    └── README.md           Diese Datei
```

---

## Bekannte Einschränkungen (MVP v1.0)

- **OAuth2:** Vollständiger PKCE-Browser-Flow (Standard-Systembrowser +
  lokaler Loopback-HTTP-Listener) ist implementiert und funktioniert
  (Gmail, Outlook, Yahoo). Weiterhin nötig ist eine eigene
  App-Registrierung beim jeweiligen Anbieter (Google Cloud Console, Azure
  App Registration etc.) – MailFS bringt keine eigene/geteilte Client-ID mit.
- **POP3:** Grundlegend implementiert; Ordnerhierarchie nicht unterstützt (POP3 kennt keine Ordner).
- **Schreiben:** Kein Verschieben von Nachrichten in v1. Löschen und Verfassen/Senden
  (siehe „Nachricht senden") werden unterstützt.
- **Verfassen (v1):** An/Cc/Bcc nur als reine E-Mail-Adressen, kein
  „Name &lt;adresse&gt;"-Format; nur Klartext-Body (kein HTML); Anhänge werden
  einzeln über wiederholtes **Anhängen...** hinzugefügt (kein Mehrfachauswahl-Dialog).
- **Anhänge (Empfang):** Werden beim Download als Teil der vollständigen EML-Datei mitgeliefert.
- **Sehr große Postfächer:** Es werden maximal 500 Nachrichten pro Ordner geladen (neueste zuerst).

---

## Geplante Erweiterungen

- Als gelesen markieren (v1.2)
- „Name &lt;adresse&gt;"-Format und HTML-Body beim Verfassen (v1.1)
- Pagination für sehr große Ordner (v1.1)

---

## Lizenz

MIT License – freie Verwendung, Änderung und Weitergabe mit Namensnennung.
